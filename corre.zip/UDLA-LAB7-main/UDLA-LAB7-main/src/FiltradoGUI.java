import javax.swing.*;

public class FiltradoGUI {
    private JComboBox comboBoxPoder2;
    private JButton filtrarButton;
    private JPanel JPanelFiltrado;
    private JTable table1;
    private JComboBox comboBoxUbicacion;
    private JButton conteoButton;
    private JTextArea textArea1;
}
